-- PhysioMind database schema
-- Run this entire script in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.patients (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  display_name text not null,
  age integer check (age is null or age between 0 and 120),
  sex text,
  contact_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.assessments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  patient_id uuid not null references public.patients(id) on delete cascade,
  specialty text not null default 'neuro',
  assessment_date date not null default current_date,
  chief_complaint text,
  history text,
  findings jsonb not null default '{}'::jsonb,
  clinical_notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.patients enable row level security;
alter table public.assessments enable row level security;

drop policy if exists "Users manage own patients" on public.patients;
create policy "Users manage own patients" on public.patients
for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "Users manage own assessments" on public.assessments;
create policy "Users manage own assessments" on public.assessments
for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index if not exists patients_user_id_idx on public.patients(user_id);
create index if not exists assessments_user_id_idx on public.assessments(user_id);
create index if not exists assessments_patient_id_idx on public.assessments(patient_id);

-- Keep updated_at current.
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end; $$;

drop trigger if exists patients_updated_at on public.patients;
create trigger patients_updated_at before update on public.patients
for each row execute function public.set_updated_at();

drop trigger if exists assessments_updated_at on public.assessments;
create trigger assessments_updated_at before update on public.assessments
for each row execute function public.set_updated_at();