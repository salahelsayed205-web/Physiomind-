# PhysioMind

A responsive bilingual (English/Arabic) physiotherapy assessment workspace built with React, Vite and Supabase.

## Included
- Email/password sign up, sign in and sign out through Supabase Auth.
- Per-user patient and assessment records.
- Row Level Security (RLS) policies in `supabase/schema.sql`.
- Neuro, Ortho, Pediatric and Cardiorespiratory assessment sections.
- Transparent clinical review panel: missing information, safety prompts and findings to review. It does **not** diagnose.
- Browser print / Save as PDF for an assessment.
- PWA manifest and lightweight service worker.

## 1. Create Supabase project
1. Create a project at https://supabase.com.
2. Open **SQL Editor**, paste all of `supabase/schema.sql`, and run it.
3. In **Project Settings → API**, copy the Project URL and `anon` / publishable key.
4. In Authentication settings, enable Email provider. For a quick test, you may disable email confirmation; for real use, keep confirmation enabled and configure SMTP.

## 2. Configure the app
Copy `.env.example` to `.env` and fill in:
```
VITE_SUPABASE_URL=https://YOUR_PROJECT_ID.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
```
Only the Supabase anon/publishable key belongs in the frontend. **Never put the service_role key in this app or share it.**

## 3. Run locally
```
npm install
npm run dev
```
Open the local URL shown by Vite.

## 4. Publish on Vercel
1. Upload this project to a private GitHub repository.
2. Import that repository in https://vercel.com.
3. Set the build command to `npm run build` and output directory to `dist`.
4. Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` under Vercel → Project → Settings → Environment Variables.
5. Deploy. In Supabase → Authentication → URL Configuration, add your deployed Vercel URL to **Site URL** and **Redirect URLs**.

## Privacy and clinical safety
- RLS ensures authenticated users can access only rows whose `user_id` matches their authenticated account. Do not remove these policies.
- Use a test dataset until you have reviewed local privacy, consent, retention, backup, and applicable legal requirements. Avoid entering patient names, phone numbers, addresses, IDs, or other directly identifying information in early testing.
- Supabase manages encrypted connections; review your project region, backup and security settings before real clinical use.
- Do not store passwords, access tokens, or service-role keys in patient notes.
- Clinical review prompts are educational decision-support only, not validated diagnostic algorithms. They cannot replace a full examination, medical referral, or clinician judgment. Always assess urgent red flags and follow local escalation pathways.
- This starter is not a certified medical device and has not undergone clinical validation or security audit.

## Current limitations
- This starter uses simple patient/assessment CRUD and print-to-PDF; it does not yet include file uploads, team sharing, audit trails, billing, or validated diagnosis scoring.
- PWA caching is basic and does not make Supabase data available offline.
