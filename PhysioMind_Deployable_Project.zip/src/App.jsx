import React, { useEffect, useMemo, useState } from 'react'
import { supabase, isConfigured } from './supabase'
import { Activity, Users, ClipboardList, Plus, Search, LogOut, Globe, FileText, ShieldCheck, AlertTriangle, Brain, HeartPulse, Baby, Bone, X, Save, ChevronRight } from 'lucide-react'

const specialties = [
  { id:'neuro', en:'Neurological', ar:'عصبي', icon:Brain },
  { id:'ortho', en:'Orthopedic', ar:'عظام', icon:Bone },
  { id:'pediatric', en:'Pediatric', ar:'أطفال', icon:Baby },
  { id:'cardio', en:'Cardiorespiratory', ar:'قلبي تنفسي', icon:HeartPulse }
]
const t = {
  en: {
    tagline:'Clinical assessment workspace', dashboard:'Dashboard', patients:'Patients', assessments:'Assessments', newPatient:'New patient',
    newAssessment:'New assessment', search:'Search patients...', totalPatients:'Total patients', totalAssessments:'Assessments',
    recent:'Recent patients', welcome:'Welcome to PhysioMind', signIn:'Sign in', signUp:'Create account', email:'Email address',
    password:'Password', fullName:'Patient display name / code', age:'Age', sex:'Sex', select:'Select', male:'Male', female:'Female',
    other:'Other / not specified', save:'Save', cancel:'Cancel', specialty:'Specialty', patient:'Patient', choosePatient:'Choose patient',
    complaint:'Chief complaint', history:'Relevant history', notes:'Clinical notes', date:'Assessment date', findings:'Assessment findings',
    neuroTitle:'Neurological screen', orthoTitle:'Orthopedic screen', pedTitle:'Pediatric screen', cardioTitle:'Cardiorespiratory screen',
    mmt:'MMT / key muscle groups', tone:'Tone', reflexes:'Reflexes', sensation:'Sensation', coordination:'Coordination',
    pain:'Pain (0–10)', rom:'ROM findings', special:'Special tests', palpation:'Palpation', function:'Functional / developmental skills',
    vitals:'Vitals', spo2:'SpO₂ (%)', hr:'Heart rate (bpm)', bp:'Blood pressure', rr:'Respiratory rate', precautions:'Precautions / red flags',
    review:'Clinical review prompts', missing:'Information to complete', safety:'Safety prompts', disclaimer:'Decision support only — not a diagnosis.',
    print:'Print / Save PDF', noPatients:'No patients yet. Add your first patient to begin.', noAssessments:'No assessments yet.',
    signOut:'Sign out', setup:'Connect Supabase to activate cloud accounts', setupText:'Create a Supabase project, run the included SQL schema, then add the project URL and anon key to your environment variables.',
    configError:'Supabase is not configured. Follow the setup guide in README.md.', authError:'Authentication error', nameRequired:'Enter a patient display name or code.',
    patientSaved:'Patient saved.', assessmentSaved:'Assessment saved.', delete:'Delete', open:'Open', created:'Created',
    redFlagPrompt:'Check for urgent red flags based on the patient presentation and follow local escalation pathways.',
    neuroPrompt:'Review onset, progression, cognition, cranial nerves when indicated, motor control, sensation, reflexes, balance, gait and functional impact.',
    orthoPrompt:'Correlate symptom behavior, irritability, ROM, strength, neurovascular status and relevant special tests. Do not interpret a test in isolation.',
    pedPrompt:'Consider corrected age where relevant, developmental history, family priorities, play, participation and age-appropriate standardized measures.',
    cardioPrompt:'Review symptoms, baseline vitals, exertional response, oxygen needs, contraindications and stop criteria before intervention.',
    none:'Not recorded', logoutConfirm:'Sign out of PhysioMind?', account:'Account', language:'العربية', deleteConfirm:'Delete this patient and all associated assessments?',
    patientDetails:'Patient details', assessmentList:'Assessment history', view:'View report', back:'Back to patients', clinicalSummary:'Clinical summary',
    draft:'Draft assessment', saveAssessment:'Save assessment', selectSpecialty:'Choose a specialty', noData:'No data entered'
  },
  ar: {
    tagline:'مساحة عمل للتقييم الإكلينيكي', dashboard:'الرئيسية', patients:'المرضى', assessments:'التقييمات', newPatient:'إضافة مريض',
    newAssessment:'تقييم جديد', search:'ابحث عن مريض...', totalPatients:'إجمالي المرضى', totalAssessments:'التقييمات',
    recent:'أحدث المرضى', welcome:'أهلاً بك في PhysioMind', signIn:'تسجيل الدخول', signUp:'إنشاء حساب', email:'البريد الإلكتروني',
    password:'كلمة المرور', fullName:'اسم مختصر أو كود المريض', age:'العمر', sex:'النوع', select:'اختر', male:'ذكر', female:'أنثى',
    other:'آخر / غير محدد', save:'حفظ', cancel:'إلغاء', specialty:'التخصص', patient:'المريض', choosePatient:'اختر المريض',
    complaint:'الشكوى الرئيسية', history:'التاريخ المرضي المرتبط', notes:'ملاحظات إكلينيكية', date:'تاريخ التقييم', findings:'نتائج التقييم',
    neuroTitle:'فحص عصبي', orthoTitle:'فحص عظام', pedTitle:'فحص أطفال', cardioTitle:'فحص قلبي تنفسي',
    mmt:'القوة العضلية / مجموعات عضلية أساسية', tone:'Muscle tone', reflexes:'Reflexes', sensation:'Sensation', coordination:'Coordination',
    pain:'الألم (0–10)', rom:'مدى الحركة ROM', special:'Special tests', palpation:'Palpation', function:'المهارات الوظيفية / التطورية',
    vitals:'العلامات الحيوية', spo2:'SpO₂ (%)', hr:'معدل ضربات القلب', bp:'ضغط الدم', rr:'معدل التنفس', precautions:'احتياطات / علامات خطر',
    review:'مراجعة إكلينيكية', missing:'بيانات يُفضل استكمالها', safety:'تنبيهات السلامة', disclaimer:'مساعدة في التفكير الإكلينيكي فقط — ليست تشخيصًا.',
    print:'طباعة / حفظ PDF', noPatients:'لا يوجد مرضى بعد. أضف أول مريض للبدء.', noAssessments:'لا توجد تقييمات بعد.',
    signOut:'تسجيل الخروج', setup:'اربط Supabase لتفعيل الحسابات السحابية', setupText:'أنشئ مشروع Supabase وشغّل ملف SQL المرفق، ثم أضف رابط المشروع ومفتاح anon إلى متغيرات البيئة.',
    configError:'Supabase غير مُعدّ. اتبع خطوات README.md.', authError:'خطأ في تسجيل الدخول', nameRequired:'أدخل اسمًا مختصرًا أو كودًا للمريض.',
    patientSaved:'تم حفظ المريض.', assessmentSaved:'تم حفظ التقييم.', delete:'حذف', open:'فتح', created:'تاريخ الإضافة',
    redFlagPrompt:'افحص علامات الخطر العاجلة وفقًا لعرض الحالة واتبع مسار الإحالة/التصعيد المعتمد.',
    neuroPrompt:'راجع بداية الأعراض وتطورها والإدراك والأعصاب القحفية عند الحاجة والتحكم الحركي والإحساس والمنعكسات والاتزان والمشي والتأثير الوظيفي.',
    orthoPrompt:'اربط سلوك الأعراض وشدتها بمدى الحركة والقوة والحالة العصبية الوعائية والاختبارات الخاصة. لا تفسر أي اختبار منفردًا.',
    pedPrompt:'راعِ العمر التطوري والتاريخ النمائي وأولويات الأسرة واللعب والمشاركة والاختبارات المعيارية المناسبة للعمر.',
    cardioPrompt:'راجع الأعراض والعلامات الحيوية والاستجابة للمجهود والاحتياج للأكسجين وموانع العلاج ومعايير إيقاف الجلسة.',
    none:'غير مسجل', logoutConfirm:'تسجيل الخروج من PhysioMind؟', account:'الحساب', language:'English', deleteConfirm:'حذف هذا المريض وكل التقييمات المرتبطة به؟',
    patientDetails:'بيانات المريض', assessmentList:'سجل التقييمات', view:'عرض التقرير', back:'العودة للمرضى', clinicalSummary:'الملخص الإكلينيكي',
    draft:'تقييم جديد', saveAssessment:'حفظ التقييم', selectSpecialty:'اختر التخصص', noData:'لا توجد بيانات مدخلة'
  }
}
const field = (label, value, onChange, type='text', placeholder='') => ({label,value,onChange,type,placeholder})
function App(){
  const [lang,setLang] = useState('en')
  const [session,setSession] = useState(null)
  const [authMode,setAuthMode] = useState('signin')
  const [email,setEmail] = useState('')
  const [password,setPassword] = useState('')
  const [authBusy,setAuthBusy] = useState(false)
  const [error,setError] = useState('')
  const [notice,setNotice] = useState('')
  const [patients,setPatients] = useState([])
  const [assessments,setAssessments] = useState([])
  const [page,setPage] = useState('dashboard')
  const [selectedPatient,setSelectedPatient] = useState(null)
  const [selectedAssessment,setSelectedAssessment] = useState(null)
  const [query,setQuery] = useState('')
  const [showPatientForm,setShowPatientForm] = useState(false)
  const [patientForm,setPatientForm] = useState({display_name:'',age:'',sex:''})
  const [assessmentForm,setAssessmentForm] = useState({patient_id:'',specialty:'neuro',assessment_date:new Date().toISOString().slice(0,10),chief_complaint:'',history:'',clinical_notes:'',findings:{}})
  const [saving,setSaving] = useState(false)
  const rtl = lang==='ar', tr=t[lang]
  const setFinding=(key,value)=>setAssessmentForm(f=>({...f,findings:{...f.findings,[key]:value}}))
  useEffect(()=>{
    if(!isConfigured) return
    supabase.auth.getSession().then(({data})=>setSession(data.session))
    const {data:{subscription}}=supabase.auth.onAuthStateChange((_e,s)=>setSession(s))
    return ()=>subscription.unsubscribe()
  },[])
  useEffect(()=>{ if(session) loadData(); else {setPatients([]);setAssessments([])} },[session])
  async function loadData(){
    const [p,a]=await Promise.all([
      supabase.from('patients').select('*').order('created_at',{ascending:false}),
      supabase.from('assessments').select('*').order('assessment_date',{ascending:false})
    ])
    if(p.error) setError(p.error.message); else setPatients(p.data||[])
    if(a.error) setError(a.error.message); else setAssessments(a.data||[])
  }
  async function authenticate(e){
    e.preventDefault(); setError(''); setAuthBusy(true)
    const fn=authMode==='signup'?supabase.auth.signUp({email,password}):supabase.auth.signInWithPassword({email,password})
    const {error}=await fn
    setAuthBusy(false)
    if(error) setError(error.message)
    else if(authMode==='signup') setNotice(lang==='ar'?'تم إنشاء الحساب. افحص بريدك لتأكيده إذا كان التأكيد مفعّلًا.':'Account created. Check your email if confirmation is enabled.')
  }
  async function addPatient(e){
    e.preventDefault(); if(!patientForm.display_name.trim()){setError(tr.nameRequired);return}
    setSaving(true);setError('')
    const {data,error}=await supabase.from('patients').insert({user_id:session.user.id,display_name:patientForm.display_name.trim(),age:patientForm.age?Number(patientForm.age):null,sex:patientForm.sex||null}).select().single()
    setSaving(false)
    if(error){setError(error.message);return}
    setPatients(p=>[data,...p]);setPatientForm({display_name:'',age:'',sex:''});setShowPatientForm(false);setNotice(tr.patientSaved)
  }
  async function deletePatient(p){
    if(!confirm(tr.deleteConfirm))return
    const {error}=await supabase.from('patients').delete().eq('id',p.id)
    if(error)setError(error.message);else{setPatients(x=>x.filter(y=>y.id!==p.id));setAssessments(x=>x.filter(y=>y.patient_id!==p.id));setSelectedPatient(null)}
  }
  function startAssessment(patient=null){
    setSelectedPatient(patient);setSelectedAssessment(null)
    setAssessmentForm({patient_id:patient?.id||'',specialty:'neuro',assessment_date:new Date().toISOString().slice(0,10),chief_complaint:'',history:'',clinical_notes:'',findings:{}})
    setPage('new-assessment')
  }
  async function saveAssessment(e){
    e.preventDefault()
    if(!assessmentForm.patient_id){setError(lang==='ar'?'اختر المريض أولاً.':'Select a patient first.');return}
    setSaving(true);setError('')
    const payload={...assessmentForm,user_id:session.user.id,age:undefined}
    const {data,error}=await supabase.from('assessments').insert(payload).select().single()
    setSaving(false)
    if(error){setError(error.message);return}
    setAssessments(a=>[data,...a]);setSelectedAssessment(data);setPage('report');setNotice(tr.assessmentSaved)
  }
  const filtered=patients.filter(p=>p.display_name.toLowerCase().includes(query.toLowerCase()))
  const currentPatient=selectedPatient||patients.find(p=>p.id===selectedAssessment?.patient_id)
  const review=useMemo(()=>{
    const f=assessmentForm.findings||{}, missing=[]
    if(!assessmentForm.chief_complaint.trim())missing.push(tr.complaint)
    if(!assessmentForm.history.trim())missing.push(tr.history)
    if(assessmentForm.specialty==='neuro'){['tone','reflexes','sensation','mmt'].forEach(k=>{if(!f[k])missing.push(tr[k]||k)})}
    if(assessmentForm.specialty==='ortho'){['pain','rom','special_tests'].forEach(k=>{if(!f[k])missing.push(({pain:tr.pain,rom:tr.rom,special_tests:tr.special})[k])})}
    if(assessmentForm.specialty==='cardio'){['spo2','hr','bp','rr'].forEach(k=>{if(!f[k])missing.push(({spo2:tr.spo2,hr:tr.hr,bp:tr.bp,rr:tr.rr})[k])})}
    const prompts=[tr.redFlagPrompt,({neuro:tr.neuroPrompt,ortho:tr.orthoPrompt,pediatric:tr.pedPrompt,cardio:tr.cardioPrompt})[assessmentForm.specialty]]
    return {missing,prompts}
  },[assessmentForm,lang])
  const titleFor=(s)=>specialties.find(x=>x.id===s)?.[lang]||s
  const updateField=(k,v)=>setAssessmentForm(f=>({...f,[k]:v}))
  const Input=({label,value,onChange,type='text',placeholder=''})=><label className="field"><span>{label}</span><input type={type} value={value??''} onChange={e=>onChange(e.target.value)} placeholder={placeholder}/></label>
  const Textarea=({label,value,onChange,rows=3})=><label className="field"><span>{label}</span><textarea rows={rows} value={value??''} onChange={e=>onChange(e.target.value)}/></label>
  const Select=({label,value,onChange,options})=><label className="field"><span>{label}</span><select value={value??''} onChange={e=>onChange(e.target.value)}>{options.map(o=><option key={o.value} value={o.value}>{o.label}</option>)}</select></label>
  if(!isConfigured) return <div className="setup-screen" dir={rtl?'rtl':'ltr'}><div className="setup-card"><Logo/><button className="lang-btn" onClick={()=>setLang(rtl?'en':'ar')}><Globe size={16}/>{tr.language}</button><h1>{tr.setup}</h1><p>{tr.setupText}</p><div className="setup-steps"><b>1.</b> Create Supabase project<br/><b>2.</b> Run <code>supabase/schema.sql</code><br/><b>3.</b> Copy <code>.env.example</code> to <code>.env</code> and add your URL + anon key<br/><b>4.</b> Run <code>npm install</code> then <code>npm run dev</code></div><p className="muted">{tr.configError}</p></div></div>
  if(!session) return <div className="auth-screen" dir={rtl?'rtl':'ltr'}><div className="auth-card"><Logo/><p className="muted">{tr.tagline}</p><h1>{tr.welcome}</h1><div className="auth-tabs"><button className={authMode==='signin'?'active':''} onClick={()=>setAuthMode('signin')}>{tr.signIn}</button><button className={authMode==='signup'?'active':''} onClick={()=>setAuthMode('signup')}>{tr.signUp}</button></div><form onSubmit={authenticate}><Input label={tr.email} value={email} onChange={setEmail} type="email"/><Input label={tr.password} value={password} onChange={setPassword} type="password"/><button className="primary full" disabled={authBusy}>{authBusy?'…':authMode==='signin'?tr.signIn:tr.signUp}</button></form>{error&&<p className="error">{error}</p>}{notice&&<p className="success">{notice}</p>}<button className="lang-link" onClick={()=>setLang(rtl?'en':'ar')}><Globe size={15}/>{tr.language}</button></div></div>
  return <div className="app" dir={rtl?'rtl':'ltr'}>
    <aside className="sidebar"><Logo/><div className="nav-label">{tr.dashboard}</div><button className={page==='dashboard'?'nav active':'nav'} onClick={()=>setPage('dashboard')}><Activity size={18}/>{tr.dashboard}</button><button className={page==='patients'?'nav active':'nav'} onClick={()=>setPage('patients')}><Users size={18}/>{tr.patients}<span>{patients.length}</span></button><button className={page==='assessments'?'nav active':'nav'} onClick={()=>setPage('assessments')}><ClipboardList size={18}/>{tr.assessments}<span>{assessments.length}</span></button><div className="sidebar-bottom"><div className="secure"><ShieldCheck size={17}/><span>Private workspace<br/><small>RLS protected</small></span></div><button className="nav" onClick={()=>setLang(rtl?'en':'ar')}><Globe size={18}/>{tr.language}</button><button className="nav" onClick={()=>supabase.auth.signOut()}><LogOut size={18}/>{tr.signOut}</button></div></aside>
    <main className="main"><header className="topbar"><div><div className="eyebrow">PHYSIOMIND / {tr.account}</div><div className="user-email">{session.user.email}</div></div><div className="top-actions"><button className="icon-btn" onClick={()=>setLang(rtl?'en':'ar')}><Globe size={17}/>{tr.language}</button><button className="primary" onClick={()=>startAssessment()}><Plus size={17}/>{tr.newAssessment}</button></div></header>
    <div className="content">
      {error&&<div className="alert error-box"><AlertTriangle size={17}/>{error}<button onClick={()=>setError('')}><X size={15}/></button></div>}
      {notice&&<div className="alert success-box">{notice}<button onClick={()=>setNotice('')}><X size={15}/></button></div>}
      {page==='dashboard'&&<><div className="page-heading"><div><p className="eyebrow">OVERVIEW</p><h1>{tr.dashboard}</h1><p className="muted">{tr.tagline}</p></div><button className="primary" onClick={()=>setShowPatientForm(true)}><Plus size={17}/>{tr.newPatient}</button></div><div className="stats"><Stat icon={<Users/>} label={tr.totalPatients} value={patients.length}/><Stat icon={<ClipboardList/>} label={tr.totalAssessments} value={assessments.length}/><Stat icon={<Activity/>} label={tr.specialty} value="4"/></div><section className="panel"><div className="panel-head"><h2>{tr.recent}</h2><button className="text-btn" onClick={()=>setPage('patients')}>{tr.patients}<ChevronRight size={15}/></button></div>{patients.length===0?<Empty text={tr.noPatients}/>:<div className="patient-list">{patients.slice(0,6).map(p=><PatientRow key={p.id} p={p} onClick={()=>{setSelectedPatient(p);setPage('patient')}}/>)}</div>}</section><div className="specialty-grid">{specialties.map(s=><button key={s.id} className="specialty-card" onClick={()=>{setAssessmentForm(f=>({...f,specialty:s.id}));startAssessment()}}><s.icon size={22}/><b>{s[lang]}</b><span>{tr.newAssessment}</span></button>)}</div></>}
      {page==='patients'&&<><div className="page-heading"><div><p className="eyebrow">RECORDS</p><h1>{tr.patients}</h1></div><button className="primary" onClick={()=>setShowPatientForm(true)}><Plus size={17}/>{tr.newPatient}</button></div><div className="search"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder={tr.search}/></div>{filtered.length===0?<Empty text={tr.noPatients}/>:<div className="patient-list panel">{filtered.map(p=><PatientRow key={p.id} p={p} onClick={()=>{setSelectedPatient(p);setPage('patient')}}/>)}</div>}</>}
      {page==='patient'&&selectedPatient&&<><button className="back-btn" onClick={()=>setPage('patients')}>← {tr.back}</button><div className="page-heading"><div><p className="eyebrow">{tr.patientDetails}</p><h1>{selectedPatient.display_name}</h1><p className="muted">{selectedPatient.age?`${selectedPatient.age} · `:''}{selectedPatient.sex||''}</p></div><div className="row-actions"><button className="danger-btn" onClick={()=>deletePatient(selectedPatient)}>{tr.delete}</button><button className="primary" onClick={()=>startAssessment(selectedPatient)}><Plus size={17}/>{tr.newAssessment}</button></div></div><section className="panel"><div className="panel-head"><h2>{tr.assessmentList}</h2></div>{assessments.filter(a=>a.patient_id===selectedPatient.id).length===0?<Empty text={tr.noAssessments}/>:assessments.filter(a=>a.patient_id===selectedPatient.id).map(a=><div className="assessment-row" key={a.id}><div><b>{titleFor(a.specialty)}</b><small>{a.assessment_date} · {a.chief_complaint||tr.none}</small></div><button className="text-btn" onClick={()=>{setSelectedAssessment(a);setPage('report')}}>{tr.view}<ChevronRight size={15}/></button></div>)}</section></>}
      {page==='new-assessment'&&<><button className="back-btn" onClick={()=>selectedPatient?setPage('patient'):setPage('patients')}>← {tr.back}</button><div className="page-heading"><div><p className="eyebrow">{tr.draft}</p><h1>{tr.newAssessment}</h1></div></div><form onSubmit={saveAssessment} className="assessment-layout"><div className="form-column"><section className="panel form-panel"><h2>{tr.patientDetails}</h2><Select label={tr.patient} value={assessmentForm.patient_id} onChange={v=>updateField('patient_id',v)} options={[{value:'',label:tr.choosePatient},...patients.map(p=>({value:p.id,label:p.display_name}))]}/><Select label={tr.specialty} value={assessmentForm.specialty} onChange={v=>updateField('specialty',v)} options={specialties.map(s=>({value:s.id,label:s[lang]}))}/><Input label={tr.date} type="date" value={assessmentForm.assessment_date} onChange={v=>updateField('assessment_date',v)}/><Textarea label={tr.complaint} value={assessmentForm.chief_complaint} onChange={v=>updateField('chief_complaint',v)}/><Textarea label={tr.history} value={assessmentForm.history} onChange={v=>updateField('history',v)}/></section><section className="panel form-panel"><h2>{tr.findings} — {titleFor(assessmentForm.specialty)}</h2>{assessmentForm.specialty==='neuro'&&<><Textarea label={tr.mmt} value={assessmentForm.findings.mmt} onChange={v=>setFinding('mmt',v)} placeholder="e.g. R: hip flex 3/5, knee ext 4/5; L: …"/><Textarea label={tr.tone} value={assessmentForm.findings.tone} onChange={v=>setFinding('tone',v)} placeholder="Modified Ashworth / distribution / velocity dependent?"/><Textarea label={tr.reflexes} value={assessmentForm.findings.reflexes} onChange={v=>setFinding('reflexes',v)}/><Textarea label={tr.sensation} value={assessmentForm.findings.sensation} onChange={v=>setFinding('sensation',v)}/><Textarea label={tr.coordination} value={assessmentForm.findings.coordination} onChange={v=>setFinding('coordination',v)}/><Textarea label="Balance / gait / functional mobility" value={assessmentForm.findings.balance_gait} onChange={v=>setFinding('balance_gait',v)}/></>}
      {assessmentForm.specialty==='ortho'&&<><Input label={tr.pain} value={assessmentForm.findings.pain} onChange={v=>setFinding('pain',v)}/><Textarea label={tr.rom} value={assessmentForm.findings.rom} onChange={v=>setFinding('rom',v)}/><Textarea label="Strength / MMT" value={assessmentForm.findings.strength} onChange={v=>setFinding('strength',v)}/><Textarea label={tr.special} value={assessmentForm.findings.special_tests} onChange={v=>setFinding('special_tests',v)}/><Textarea label={tr.palpation} value={assessmentForm.findings.palpation} onChange={v=>setFinding('palpation',v)}/><Textarea label="Neurovascular screen" value={assessmentForm.findings.neurovascular} onChange={v=>setFinding('neurovascular',v)}/></>}
      {assessmentForm.specialty==='pediatric'&&<><Textarea label={tr.function} value={assessmentForm.findings.function} onChange={v=>setFinding('function',v)}/><Textarea label="Developmental history / milestones" value={assessmentForm.findings.milestones} onChange={v=>setFinding('milestones',v)}/><Textarea label="Posture / movement quality / tone" value={assessmentForm.findings.movement} onChange={v=>setFinding('movement',v)}/><Textarea label="Family priorities / participation" value={assessmentForm.findings.family} onChange={v=>setFinding('family',v)}/></>}
      {assessmentForm.specialty==='cardio'&&<><div className="two-col"><Input label={tr.spo2} value={assessmentForm.findings.spo2} onChange={v=>setFinding('spo2',v)}/><Input label={tr.hr} value={assessmentForm.findings.hr} onChange={v=>setFinding('hr',v)}/><Input label={tr.bp} value={assessmentForm.findings.bp} onChange={v=>setFinding('bp',v)}/><Input label={tr.rr} value={assessmentForm.findings.rr} onChange={v=>setFinding('rr',v)}/></div><Textarea label="Breathing pattern / chest expansion" value={assessmentForm.findings.breathing} onChange={v=>setFinding('breathing',v)}/><Textarea label="Exercise response / symptoms" value={assessmentForm.findings.response} onChange={v=>setFinding('response',v)}/><Textarea label="Auscultation / cough / sputum" value={assessmentForm.findings.auscultation} onChange={v=>setFinding('auscultation',v)}/></>}
      <Textarea label={tr.precautions} value={assessmentForm.findings.precautions} onChange={v=>setFinding('precautions',v)}/><Textarea label={tr.notes} value={assessmentForm.clinical_notes} onChange={v=>updateField('clinical_notes',v)}/></section><button className="primary save-btn" disabled={saving}><Save size={17}/>{saving?'…':tr.saveAssessment}</button></div><aside className="review-panel"><div className="review-title"><ShieldCheck size={19}/><h3>{tr.review}</h3></div><p className="muted">{tr.disclaimer}</p><h4>{tr.missing}</h4>{review.missing.length?review.missing.map(x=><div className="review-item" key={x}><span className="dot amber"/>{x}</div>):<div className="review-item"><span className="dot green"/> {lang==='ar'?'الحقول الأساسية المدققة مكتملة':'Core prompts completed'}</div>}<h4>{tr.safety}</h4>{review.prompts.map((p,i)=><p className="prompt" key={i}>{p}</p>)}</aside></form></>}
      {page==='assessments'&&<><div className="page-heading"><div><p className="eyebrow">CLINICAL RECORDS</p><h1>{tr.assessments}</h1></div><button className="primary" onClick={()=>startAssessment()}><Plus size={17}/>{tr.newAssessment}</button></div>{assessments.length===0?<Empty text={tr.noAssessments}/>:<section className="panel">{assessments.map(a=><div className="assessment-row" key={a.id}><div><b>{titleFor(a.specialty)}</b><small>{patients.find(p=>p.id===a.patient_id)?.display_name||'—'} · {a.assessment_date}</small></div><button className="text-btn" onClick={()=>{setSelectedAssessment(a);setSelectedPatient(patients.find(p=>p.id===a.patient_id));setPage('report')}}>{tr.view}<ChevronRight size={15}/></button></div>)}</section>}</>}
      {page==='report'&&selectedAssessment&&<><button className="back-btn" onClick={()=>currentPatient?setPage('patient'):setPage('assessments')}>← {tr.back}</button><div className="page-heading no-print"><div><p className="eyebrow">{tr.clinicalSummary}</p><h1>{currentPatient?.display_name||'Patient'} — {titleFor(selectedAssessment.specialty)}</h1><p className="muted">{selectedAssessment.assessment_date}</p></div><button className="primary" onClick={()=>window.print()}><FileText size={17}/>{tr.print}</button></div><article className="panel report"><h2>{tr.patientDetails}</h2><p><b>{tr.patient}:</b> {currentPatient?.display_name||'—'} &nbsp; <b>{tr.specialty}:</b> {titleFor(selectedAssessment.specialty)}</p><h2>{tr.complaint}</h2><p>{selectedAssessment.chief_complaint||tr.none}</p><h2>{tr.history}</h2><p>{selectedAssessment.history||tr.none}</p><h2>{tr.findings}</h2>{Object.entries(selectedAssessment.findings||{}).filter(([,v])=>v).map(([k,v])=><div className="report-field" key={k}><b>{k.replaceAll('_',' ')}:</b><p>{v}</p></div>)}<h2>{tr.notes}</h2><p>{selectedAssessment.clinical_notes||tr.none}</p><div className="disclaimer"><AlertTriangle size={17}/>{tr.disclaimer} Review all findings clinically and follow local safety/referral pathways.</div></article></>}
    </div></main>
    {showPatientForm&&<div className="modal-backdrop" onClick={()=>setShowPatientForm(false)}><div className="modal" onClick={e=>e.stopPropagation()}><div className="modal-head"><h2>{tr.newPatient}</h2><button onClick={()=>setShowPatientForm(false)}><X/></button></div><form onSubmit={addPatient}><Input label={tr.fullName} value={patientForm.display_name} onChange={v=>setPatientForm(f=>({...f,display_name:v}))}/><div className="two-col"><Input label={tr.age} type="number" value={patientForm.age} onChange={v=>setPatientForm(f=>({...f,age:v}))}/><Select label={tr.sex} value={patientForm.sex} onChange={v=>setPatientForm(f=>({...f,sex:v}))} options={[{value:'',label:tr.select},{value:'male',label:tr.male},{value:'female',label:tr.female},{value:'other',label:tr.other}]}/></div><div className="modal-actions"><button type="button" className="secondary" onClick={()=>setShowPatientForm(false)}>{tr.cancel}</button><button className="primary" disabled={saving}>{saving?'…':tr.save}</button></div></form></div></div>}
  </div>
}
function Logo(){return <div className="brand"><div className="brand-mark"><Activity size={22}/></div><div><b>PhysioMind</b><small>CLINICAL WORKSPACE</small></div></div>}
function Stat({icon,label,value}){return <div className="stat-card"><div className="stat-icon">{icon}</div><div><small>{label}</small><strong>{value}</strong></div></div>}
function PatientRow({p,onClick}){return <button className="patient-row" onClick={onClick}><div className="avatar">{p.display_name.slice(0,1).toUpperCase()}</div><div className="patient-info"><b>{p.display_name}</b><small>{p.age?`${p.age} · `:''}{p.sex||'—'}</small></div><ChevronRight size={18}/></button>}
function Empty({text}){return <div className="empty"><div className="empty-icon"><ClipboardList size={23}/></div><p>{text}</p></div>}
export default App
